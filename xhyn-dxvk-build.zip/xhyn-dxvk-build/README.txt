XHYN V: сборка DXVK-Sarek 3.0.2 через GitHub Actions (всё делается с телефона)

Разово: в репозитории откройте .github/workflows/build.yml (карандаш) и вставьте содержимое
build.yml из этого набора (короткий файл, он только распаковывает zip).

Каждый раз: Add file -> Upload files -> выберите xhyn-dxvk-build.zip (имя именно такое, файл
заменится) -> Commit changes. Потом Actions -> Run workflow.
Результат: три артефакта ...-sc1, ...-sc2, ...-sc3.

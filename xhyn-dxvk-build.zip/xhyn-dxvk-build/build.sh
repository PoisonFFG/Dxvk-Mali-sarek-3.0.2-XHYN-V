#!/usr/bin/env bash
# Вся сборка DXVK-Sarek 3.0.2 для XHYN V. Вызывается из .github/workflows/build.yml:
#   NDK_PATH=... VARIANT=1|2|3 bash build.sh
set -euo pipefail

KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SDL3_BRANCH="release-3.2.x"

install_tools() {
  sudo apt-get update -qq
  sudo apt-get install -y ninja-build glslang-tools patchelf pkg-config python3-pip
  pip install --user meson
  export PATH="$HOME/.local/bin:$PATH"
}

clone_sources() {
  # В zip с GitHub submodule пустые, поэтому клонируем с --recursive.
  git clone --recursive --branch dxvk-mali-unified https://github.com/zeyadadev/DXVK-Sarek.git src \
    || { rm -rf src; git clone --recursive --branch v3.0.2-mali-compat-r1 https://github.com/zeyadadev/DXVK-Sarek.git src; }
  ( cd src && git log -1 --format='commit %H%n%s' && git submodule status )
  test -f src/include/vulkan/include/vulkan/vulkan.h
  test -d src/include/native/directx
}

apply_patches() {
  cd src
  for p in xhyn-sdl3-export.patch xhyn-swapchain-experiments.patch; do
    patch -p1 --dry-run < "$KIT/$p"
    patch -p1 < "$KIT/$p"
  done
  cd ..
}

sdl3_headers() {
  # DXVK грузит libSDL3.so сам через dlopen, нужны только заголовки.
  git clone --depth 1 --branch "$SDL3_BRANCH" https://github.com/libsdl-org/SDL.git sdl3 \
    || git clone --depth 1 https://github.com/libsdl-org/SDL.git sdl3
  mkdir -p "$PWD/pc"
  printf 'prefix=%s\nincludedir=${prefix}/include\nName: sdl3\nDescription: headers only\nVersion: 3.2.0\nCflags: -I${includedir}\n' \
    "$PWD/sdl3" > pc/sdl3.pc
  test -f sdl3/include/SDL3/SDL_vulkan.h
  PKG_CONFIG_LIBDIR="$PWD/pc" pkg-config --cflags sdl3
}

write_cross_file() {
  local TC="$NDK_PATH/toolchains/llvm/prebuilt/linux-x86_64/bin"
  cat > cross.txt <<EOF
[binaries]
c = '$TC/aarch64-linux-android30-clang'
cpp = '$TC/aarch64-linux-android30-clang++'
ar = '$TC/llvm-ar'
strip = '$TC/llvm-strip'
pkg-config = 'pkg-config'

[host_machine]
system = 'android'
cpu_family = 'aarch64'
cpu = 'aarch64'
endian = 'little'

[properties]
needs_exe_wrapper = true
pkg_config_libdir = '$PWD/pc'

[built-in options]
c_link_args = ['-Wl,-z,max-page-size=16384']
cpp_link_args = ['-Wl,-z,max-page-size=16384']
EOF
}

configure_and_compile() {
  export PATH="$HOME/.local/bin:$PATH"
  ( cd src
    meson setup build --cross-file ../cross.txt --buildtype release \
      -Dnative_sdl3=enabled -Dnative_sdl2=disabled -Dnative_glfw=disabled \
      -Denable_d3d8=false -Denable_d3d9=false -Denable_d3d10=false \
      -Dcpp_args="-DXHYN_SC_VARIANT=$VARIANT" \
      -Denable_d3d11=true -Denable_dxgi=true 2>&1 | tee ../configure.log
    meson compile -C build 2>&1 | tee ../build.log )
}

postprocess() {
  local TC="$NDK_PATH/toolchains/llvm/prebuilt/linux-x86_64/bin"
  mkdir -p out
  cp -L src/build/src/dxgi/libdxvk_dxgi.so*   out/ 2>/dev/null || true
  cp -L src/build/src/d3d11/libdxvk_d3d11.so* out/ 2>/dev/null || true
  ( cd out
    for n in dxgi d3d11; do
      real=$(ls libdxvk_$n.so* | head -1)
      if [ "$real" != "libdxvk_$n.so" ]; then
        cp -L "$real" tmp_$n.so && rm -f libdxvk_$n.so* && mv tmp_$n.so libdxvk_$n.so
      fi
    done
    "$TC/llvm-strip" --strip-unneeded libdxvk_dxgi.so libdxvk_d3d11.so
    patchelf --set-soname libdxvk_dxgi.so  libdxvk_dxgi.so
    patchelf --set-soname libdxvk_d3d11.so libdxvk_d3d11.so
    for lib in libdxvk_dxgi.so libdxvk_d3d11.so; do
      patchelf --remove-rpath "$lib"
      for need in $(patchelf --print-needed "$lib" | grep '^libdxvk_dxgi\.so\.' || true); do
        patchelf --replace-needed "$need" libdxvk_dxgi.so "$lib"
      done
    done
    ls -la )
}

verify() {
  local fail=0
  ( cd out
    for lib in libdxvk_dxgi.so libdxvk_d3d11.so; do
      echo "=== $lib"
      file "$lib"
      readelf -dW "$lib" | grep -E "SONAME|NEEDED|RPATH|RUNPATH" || true
      if readelf -dW "$lib" | grep -qE "RPATH|RUNPATH"; then echo "FAIL: RPATH/RUNPATH"; exit 1; fi
      if ! readelf --dyn-syms -W "$lib" | grep -E " FUNC +GLOBAL +DEFAULT +[0-9]+ gtav_dxvk_query_runtime_info$"; then
        echo "FAIL: нет экспорта gtav_dxvk_query_runtime_info"; exit 1; fi
      if ! strings -a "$lib" | grep -q "SDL3 WSI"; then echo "FAIL: нет SDL3 WSI драйвера"; exit 1; fi
      if ! strings -a "$lib" | grep -qx "libSDL3.so"; then echo "FAIL: нет имени libSDL3.so"; exit 1; fi
    done
    readelf -dW libdxvk_d3d11.so | grep -q "NEEDED.*\[libdxvk_dxgi.so\]" \
      || { echo "FAIL: d3d11 не зависит от libdxvk_dxgi.so"; exit 1; } )
}

pack() {
  META_IN="$KIT/meta.json" python3 - <<'PY'
import json, hashlib, zipfile, os
v = os.environ["VARIANT"]
meta = json.load(open(os.environ["META_IN"]))
for n in ("libdxvk_dxgi.so", "libdxvk_d3d11.so"):
    meta["libraries"][n] = hashlib.sha256(open("out/" + n, "rb").read()).hexdigest()
meta["source"] += " | rebuilt from dxvk-mali-unified + xhyn patches (SDL3 WSI)"
meta["version"] += "-sc" + v
json.dump(meta, open("out/meta.json", "w"), indent=2)
name = "dxvk-sarek-3.0.2-mali-xhyn-sc%s.zip" % v
with zipfile.ZipFile(name, "w", zipfile.ZIP_DEFLATED) as z:
    for n in ("meta.json", "libdxvk_dxgi.so", "libdxvk_d3d11.so"):
        z.write("out/" + n, n)
print(open("out/meta.json").read())
PY
}

main() {
  : "${NDK_PATH:?NDK_PATH не задан}"
  : "${VARIANT:?VARIANT не задан}"
  install_tools
  clone_sources
  apply_patches
  sdl3_headers
  write_cross_file
  configure_and_compile
  postprocess
  verify
  pack
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then main "$@"; fi
